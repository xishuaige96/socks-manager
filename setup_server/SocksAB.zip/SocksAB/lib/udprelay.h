#ifndef UDPRELAY_H
#define UDPRELAY_H

class UdpRelay {
  public:
    UdpRelay();
};

#endif  // UDPRELAY_H
