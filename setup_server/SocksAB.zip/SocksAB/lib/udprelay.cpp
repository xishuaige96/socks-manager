#include "udprelay.h"

UdpRelay::UdpRelay() {}
