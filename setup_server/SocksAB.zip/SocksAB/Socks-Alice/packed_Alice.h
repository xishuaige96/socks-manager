#ifndef PACKEDALICE_H
#define PACKEDALICE_H

#include <string.h>
#include <unistd.h>

#include <QCommandLineParser>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QHostAddress>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QMutex>
#include <QMutexLocker>
#include <QSettings>
#include <iostream>

#include "httpproxy.h"
#include "log.h"
#include "tcpserver.h"
class Packed_Alice {
  public:
    Packed_Alice();
    ~Packed_Alice();
    QHostAddress m_localAddr;  // local addr
    quint16 m_localPort;       // local port
    quint16 m_httpport;
    QHostAddress m_serverAddr;
    quint16 m_serverPort;
    std::string m_method;
    std::string password;
    QHostAddress m_proxyAddr;
    quint16 m_proxyPort;
    TcpServer tcpServer;
    HttpProxy httpServer;
    void ParseArguments();
    void Starttcpserver();
};

#endif  // EDITDIALOG_H