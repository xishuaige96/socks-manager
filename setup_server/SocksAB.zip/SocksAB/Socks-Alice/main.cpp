
#include <string.h>
#include <unistd.h>

#include <QClipboard>
#include <QCommandLineParser>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QHostAddress>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QMutex>
#include <QMutexLocker>
#include <QSettings>
#include <iostream>

#include "httpproxy.h"
#include "log.h"
#include "tcpserver.h"

QHostAddress m_localAddr;  // local addr
quint16 m_localPort;       // local port
quint16 m_httpport;
QHostAddress m_serverAddr;
quint16 m_serverPort;
std::string m_method;
std::string password;
QHostAddress m_proxyAddr;
quint16 m_proxyPort;
TcpServer tcpServer(10, true);
HttpProxy httpServer;

void parseArguments() {
    qInfo() << QDir::currentPath();
    QStringList arguments = QCoreApplication::arguments();

    qInfo() << "Arguments : " << arguments;

    if (arguments.count() < 2) return;

    QString conf_name = arguments.at(1);

    QFile file("../conf/" + conf_name);
    QByteArray jsonData;
    if (file.open(QIODevice::ReadOnly)) {
        jsonData = file.readAll();
        qInfo() << "open file successfully!!!!!!!!!!!!!!!!!!!";
        file.close();
    } else {
        qInfo() << "file is not existed!!!!!!!!!!!!!!!!  : " << conf_name;
        return;
    }
    qInfo() << "parsing config_file.......  : " << conf_name;
    QJsonDocument jsonDocu = QJsonDocument::fromJson(jsonData);
    if (jsonDocu.isObject()) {
        QJsonObject obj_root = jsonDocu.object();
        QStringList keys = obj_root.keys();
        for (auto key : keys) {
            QJsonValue value = obj_root.value(key);
            if (value.isString()) {
                qInfo() << key << ":" << value.toString();
            } else if (value.isDouble()) {
                qInfo() << key << ": " << value.toInt();
            } else if (value.isArray()) {
                QJsonArray arr = value.toArray();
                for (int i = 0; i < arr.count(); ++i) {
                    if (arr.at(i).isString()) {
                        qInfo() << key << ": " << arr.at(i).toString();
                    }
                }
            } else if (value.isObject()) {
                QJsonObject subObj = value.toObject();
                QStringList subKeys = subObj.keys();
                for (auto subKey : subKeys) {
                    QJsonValue subValue = subObj.value(subKey);
                    if (subValue.isString()) {
                        qInfo() << subKey << ": " << subValue.toString();
                    }
                }
            }
            if (key == "m_localAddr") {
                m_localAddr = QHostAddress(value.toString());
            }
            if (key == "m_localPort") {
                m_localPort = value.toInt();
            }
            if (key == "m_serverAddr") {
                m_serverAddr = QHostAddress(value.toString());
            }
            if (key == "m_serverPort") {
                m_serverPort = value.toInt();
            }
            if (key == "m_method") {
                QString temp = value.toString();
                m_method = temp.toStdString();
            }
            if (key == "password") {
                QString temp = value.toString();
                password = temp.toStdString();
            }
            if (key == "m_proxyAddr") {
                m_proxyAddr = QHostAddress(value.toString());
            }
            if (key == "m_proxyPort") {
                m_proxyPort = value.toInt();
            }
            if (key == "m_httpport") {
                m_httpport = value.toInt();
            }
        }
    }
}

void starttcpserver() {
    parseArguments();

    if (tcpServer.listen(m_localAddr, m_localPort, m_serverAddr, m_serverPort,
                         m_method, password, m_proxyAddr, m_proxyPort)) {
        if (!httpServer.httpListen(m_localAddr, m_httpport, m_localPort)) {
            tcpServer.close();
            qInfo() << "the server has being in problem!!!";
        }
    } else {
        qInfo() << "the server has start!!!!!!!!!!!!!!!!";
    }
}



int main(int argc, char *argv[]) {
    qInstallMessageHandler(messageHandler);
    QNetworkProxyFactory::setUseSystemConfiguration(false);
    QCoreApplication a(argc, argv);

    starttcpserver();

    return a.exec();
}
