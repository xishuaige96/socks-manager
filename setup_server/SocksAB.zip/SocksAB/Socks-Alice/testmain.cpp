
#include <string.h>
#include <unistd.h>

#include <QCommandLineParser>
#include <QCoreApplication>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QHostAddress>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonValue>
#include <QMutex>
#include <QMutexLocker>
#include <QSettings>
#include <iostream>

#include "packed_Alice.h"
#include "httpproxy.h"
#include "log.h"
#include "tcpserver.h"

// QHostAddress m_localAddr;  // local addr
// quint16 m_localPort;       // local port
// quint16 m_httpport;
// QHostAddress m_serverAddr;
// quint16 m_serverPort;
// std::string m_method;
// std::string password;
// QHostAddress m_proxyAddr;
// quint16 m_proxyPort;
// TcpServer tcpServer(10, true);
// HttpProxy httpServer;


int main(int argc, char *argv[]) {
    qInstallMessageHandler(messageHandler);
    QNetworkProxyFactory::setUseSystemConfiguration(false);
    QCoreApplication a(argc, argv);
    Packed_Alice alice;
    alice.Starttcpserver();

    return a.exec();
}
